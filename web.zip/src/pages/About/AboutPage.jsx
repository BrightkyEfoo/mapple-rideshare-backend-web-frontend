import React from 'react';
import NavBar from '../../Components/NavBar/NavBar';
import Footer from '../../Components/Footer/Footer';

const AboutPage = () => {
  return (
    <div>
      <NavBar />
      <p>aaaaaaa</p>
      <Footer />
    </div>
  );
};

export default AboutPage;
