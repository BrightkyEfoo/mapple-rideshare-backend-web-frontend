import React from 'react'

const UserRow = ({user}) => {
  return (
    <div>
        <p>{user.userName}</p>
        <p></p>
    </div>
  )
}

export default UserRow